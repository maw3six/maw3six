package main

import (
	"bufio"
	"fmt"
	"io/ioutil"
	"math/rand"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"mawXscanner/core"
)

func main() {
	rand.Seed(time.Now().UnixNano())

	if _, err := os.Stat(core.Maw); os.IsNotExist(err) {
		if err := os.Mkdir(core.Maw, 0755); err != nil {
			fmt.Println("Error creating directory:", err)
			return
		}
	}

	core.Banners()

	fmt.Print("\n" + core.FR + "[+] " + core.FC + "IP/DOMAIN LIST: " + core.FW)
	var targetFile string
	fmt.Scanln(&targetFile)

	target, err := core.ReadLines(targetFile)
	if err != nil {
		fmt.Println("[!] File not found!: " + targetFile)
		os.Exit(1)
	}

	core.Signs, _ = core.ReadLines("lib-maw/SHELL-STRINGS.txt")
	core.Strings_Shells, _ = core.ReadLines("lib-maw/SHELL-STRINGS.txt")
	core.TrustedFiles, _ = core.ReadLines("lib-maw/TRUSTED-FILES.txt")

	uaLines, _ := core.ReadLines("lib-maw/User-Agents.txt")
	for _, line := range uaLines {
		core.UserAgents = append(core.UserAgents, strings.TrimSpace(line))
	}

	var ua string
	if len(core.UserAgents) > 0 {
		ua = core.UserAgents[rand.Intn(len(core.UserAgents))]
	}
	core.Headers = map[string]string{
		"User-Agent":      ua,
		"Content-type":    "*/*",
		"Accept":          "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
		"Accept-Language": "en-US,en;q=0.5",
		"Connection":      "keep-alive",
	}

	pathDir := "lib-maw/Path"
	files, err := ioutil.ReadDir(pathDir)
	if err != nil {
		fmt.Printf("[!] Failed read directory %s: %v\n", pathDir, err)
		fmt.Println("[!] Make sure the lib-maw/Path/ folder exists and contains the path file.")
		os.Exit(1)
	}

	var pathFiles []string
	for _, f := range files {
		if !f.IsDir() {
			pathFiles = append(pathFiles, f.Name())
		}
	}

	if len(pathFiles) == 0 {
		fmt.Printf("[!] There are no files on %s\n", pathDir)
		os.Exit(1)
	}

	fmt.Println(core.FG + "\n[✓] File Path Available at " + pathDir + ":" + core.FW)
	for i, file := range pathFiles {
		fmt.Printf("  %d. %s\n", i+1, file)
	}

	fmt.Print(core.FR + "\n[+] " + core.FC + "Select Path (default= DEFAULT.TXT): " + core.FW)
	reader := bufio.NewReader(os.Stdin)
	choice, _ := reader.ReadString('\n')
	choice = strings.TrimSpace(choice)

	var selectedFile string

	if choice == "" {
		selectedFile = pathFiles[0]
		fmt.Printf(core.FG+"[✓] Selected default: %s\n", selectedFile)
	} else {
		var i int
		_, err := fmt.Sscanf(choice, "%d", &i)
		if err == nil { // Parsing berhasil
			if i >= 1 && i <= len(pathFiles) {
				selectedFile = pathFiles[i-1]
			}
		}
		if selectedFile == "" {
			selectedFile = choice
		}
	}

	selectedPath := filepath.Join(pathDir, selectedFile)
	if _, err := os.Stat(selectedPath); os.IsNotExist(err) {
		fmt.Printf("[!] File not found!: %s\n", selectedPath)
		os.Exit(1)
	}

	core.Locations, err = core.ReadLines(selectedPath)
	if err != nil {
		fmt.Printf("[!] Failed read file: %v\n", err)
		os.Exit(1)
	}

	fmt.Printf(core.FG+"[✓] Succes load %d path from: %s\n", len(core.Locations), selectedFile)

	var wg sync.WaitGroup
	results := make(chan string)
	for _, site := range target {
		wg.Add(1)
		go core.CmsCheckers(site, results, &wg)
	}

	go func() {
		wg.Wait()
		close(results)
	}()

	for result := range results {
		fmt.Println(result)
	}
}
