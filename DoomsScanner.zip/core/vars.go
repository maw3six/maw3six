package core

var (
	FR  = "\033[31m"
	FC  = "\033[33m"
	FW  = "\033[37m"
	FG  = "\033[32m"
	Maw = "ResultsXmaw"

	Signs          []string
	Strings_Shells []string
	Locations      []string
	TrustedFiles   []string
	UserAgents     []string
	Headers        map[string]string
)
