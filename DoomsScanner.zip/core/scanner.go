package core

import (
	"fmt"
	"net/http"
	"path"
	"sync"
)

func Exploiter(client *http.Client, site string, directories []string, results chan<- string) {
	defer func() { _ = recover() }()

	url := "https://" + URLDomain(site)
	for _, basePath := range directories {
		cleanPath := path.Clean(basePath)
		if cleanPath == "" || cleanPath[0] != '/' {
			cleanPath = "/" + cleanPath
		}

		contents, err := SendRequest(client, url, cleanPath)
		if err == nil && contents != "" && IndexOf(contents) {
			listDirs := Extract(contents, "Files")
			for _, item := range listDirs {
				name := path.Base(item)
				if name == "." || name == ".." || name == "" {
					continue
				}
				if ExtractFiles(item) {
					if scanFile(client, url, cleanPath, name, results) {
						return
					}
				}
				if ExtractFolders(item) {
					if scanFolder(client, url, cleanPath, name, results) {
						return
					}
				}
			}
		} else {
			results <- fmt.Sprintf("[Maw - Scanner] - %s%s %s [Searching ..]", url, cleanPath, FR)
		}
	}
}

func scanFile(client *http.Client, baseAddr, basePath, fileName string, results chan<- string) bool {
	filePath := path.Clean(basePath + "/" + fileName)
	fullURL := baseAddr + filePath

	text, err := SendRequest(client, baseAddr, filePath)
	if err == nil {
		matched := false
		for _, sign := range Signs {
			if CheckBackdoors(text, sign) != "" {
				for _, shell := range Strings_Shells {
					if CheckBackdoors(text, shell) != "" {
						results <- fmt.Sprintf("[Maw - Scanner] - %s %s [HORE!]", fullURL, FG)
						AppendToFile(Maw+"/Shells.txt", fullURL+"\n")
						SendToTelegram(fullURL)
						return true
					}
				}
				results <- fmt.Sprintf("[Maw - Scanner] - %s %s [HORE!]", fullURL, FG)
				AppendToFile(Maw+"/Success.txt", fullURL+"\n")
				SendToTelegram(fullURL)
				matched = true
				break
			}
		}
		if matched {
			return true
		}
		results <- fmt.Sprintf("[Maw - Scanner] - %s %s [Searching ..]", fullURL, FR)
	} else {
		results <- fmt.Sprintf("[Maw - Scanner] - %s %s [Searching ..]", fullURL, FR)
	}
	return false
}

func scanFolder(client *http.Client, baseAddr, basePath, folderName string, results chan<- string) bool {
	folderPath := path.Clean(basePath + "/" + folderName)
	contents, err := SendRequest(client, baseAddr, folderPath)
	if err == nil {
		listItems := Extract(contents, "Files")
		for _, item := range listItems {
			name := path.Base(item)
			if name == "." || name == ".." || name == "" {
				continue
			}
			if ExtractFiles(item) {
				if scanFile(client, baseAddr, folderPath, name, results) {
					return true
				}
			}
		}
	}
	return false
}

func CmsCheckers(site string, results chan<- string, wg *sync.WaitGroup) {
	defer wg.Done()
	client := NewHTTPClient()
	Exploiter(client, site, Locations, results)
}
